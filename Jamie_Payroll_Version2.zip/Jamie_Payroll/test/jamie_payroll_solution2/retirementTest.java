package jamie_payroll_solution2;

import org.junit.Test;
import static org.junit.Assert.*;

public class retirementTest {
    
    public retirementTest() {
    }

    @Test
    public void testOvertime() {
        calculations calc = new calculations();
        retirement ret = new retirement();
        
        main.input = "yes";
        main.shift = 70;
        main.hours = 50;
        
        calc.perfCalc();
        ret.perfRetire();
        
        assertEquals(3850, calc.payroll, 0.01);
        assertEquals(192.5, ret.retirement, 0.01);
        
    }
    
    
    
    @Test
    public void testNoOvertime() {
        
        calculations calc = new calculations();
        retirement ret = new retirement();
        
        main.input = "yes";
        main.shift = 70;
        main.hours = 40;
        
        calc.perfCalc();
        ret.perfRetire();
        
        assertEquals(2800, calc.payroll, 0.01);
        assertEquals(140, ret.retirement, 0.01);
        
    }

    @Test
    public void testRegularNet() {
        calculations calc = new calculations();
        retirement ret = new retirement();
        
        main.input = "yes";
        main.shift = 50;
        main.hours = 40;
        
        calc.perfCalc();
        ret.regularNet();
        
        assertEquals(ret.net, calc.payroll, 0.01);
    }
    
}
