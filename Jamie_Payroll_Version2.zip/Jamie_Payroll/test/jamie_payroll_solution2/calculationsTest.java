package jamie_payroll_solution2;

import org.junit.Test;
import static org.junit.Assert.*;

public class calculationsTest {
    
    public calculationsTest() {
    }

    @Test
    public void testTotal() {
        calculations calc = new calculations();
        main.hours = 50;
        main.shift = 70;
        calc.perfCalc();
        assertEquals(2800, calc.regular, 0.01);
    }
    
    @Test
    public void testPayrollRegular() {
        calculations calc = new calculations();
        main.hours = 40;
        main.shift = 70;
        calc.perfCalc();
        assertEquals(2800, calc.payroll, 0.01);
    }
    
    public void testPayrollOvertime() {
        calculations calc = new calculations();
        main.hours = 50;
        main.shift = 70;
        calc.perfCalc();
        assertEquals(3850, calc.payroll, 0.01);
    }
    
    @Test
    public void testNotPayroll() {
        calculations calc = new calculations();
        main.hours = 50;
        main.shift = 70;
        calc.perfCalc();
        assertNotEquals(3500, calc.regular, 0.01);
    }

    @Test
    public void testDispCalc() {
    }
    
}
