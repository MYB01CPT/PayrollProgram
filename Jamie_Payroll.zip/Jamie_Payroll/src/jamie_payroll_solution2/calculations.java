package jamie_payroll_solution2;

public class calculations extends main {
    
    protected double total; //Variable for a regular payroll
    protected double payroll; //Variable for a payroll depending on the condition
    protected double overtime; //Variable for the overtime payment
    
    public void perfCalc() {
        
        //IF HOURS ARE GREATER THAN 40
        if (hours > 40) { //If hours are greater than 40
            
            total = 40 * shift; //Calculate the regular payment and store it in 'total'
            overtime = 1.5 * (hours - 40) * shift; //Calculate the overtime value 
            payroll = total + overtime; //Calculate the sum and store it in the payroll
            
        //IF HOURS ARE LESS THAN 40
        } else if (hours <= 40 && hours > 0) {
            
            payroll = hours * shift;
            
        }
        
    }
    
    public void dispCalc() {
        
        //IF HOURS ARE GREATER THAN 40
        if (hours > 40) { //If hours are greater than 40
            
            perfCalc(); //Perform the calculations method
            
            System.out.println("Regular pay: R" + total); //Display the regular pay
            System.out.println("Overtime: " + (hours - 40) + " hours."); //Display the overtime hours
            System.out.println("Overtime pay: R" + overtime); //Display the overtime pay
            System.out.println("Total: R" + payroll); //Display the total payroll
            
        //IF HOURS ARE LESS THAN 40
        } else if (hours <= 40 && hours > 0) {
            
            perfCalc(); //Performs the calculations method
            
            System.out.println("Regular Pay: R" + payroll); //Prints the payroll
        }
        
    }
    
}
