package jamie_payroll_solution2;

public class retirement extends calculations {

    protected double retirement; //Variable for retirement value
    protected double net; //Variable for net income
    
    public void perfRetire() {

         if (input.equalsIgnoreCase("yes")) { //If the value is equal to "yes"
            perfCalc(); //Perform the calculations method from the previous class
            retirement = payroll * 0.05; //The retirement is set to 5% of the payroll
            net = payroll - retirement; //The net payment is the retirement subtracted from the payroll
            System.out.println("Retirement deduction: R" + retirement); //Display the retirement amount
            System.out.println("Net: R" + net); //Display the net income
        } else if (input.equalsIgnoreCase("no")) {
            perfCalc();
            net = payroll;
            System.out.println("Net: R" + net);
            
        } else {
             System.out.println("Invalid input.");
        }
        
    }
    
    public void regularNet() {
        perfCalc();
        net = payroll;
        System.out.println("Net: R" + net);
    }
    
}

