package jamie_payroll_solution2;

import java.util.Scanner;
import java.io.RandomAccessFile;
import java.io.IOException;

public class main {
    
    //Declaring the variables that will be used throughout the classes
    public static String input; //Variable for user input
    public static int hours; //Variable for the hours
    public static int shift; //Variable for the shift rate.

    public static void main(String[] args) {
        
        /*
        Creating an instance of scanner and the other methods to call
        on their methods and functions.
        */
        
        Scanner sc = new Scanner(System.in);
        calculations pay = new calculations(); //'pay' is an instance of the calculations class
        retirement ret = new retirement(); //'ret' is an instance of the retirement class
        
        
        
        //Text for the welcome screen and the printed out prompts
        System.out.println("Welcome to the UrbanFurn Payroll Calculator!"); //Welcoming screen
        System.out.println("--------------------------------------------");
        System.out.println("");
        System.out.println("Please enter the hours you've worked for the week:"); //Prompts user to enter hours
        hours = sc.nextInt(); //Hours is collected from user input
        System.out.println("");
        System.out.println("Please enter your shift number: (1, 2, or 3)"); //Prompts user to enter shift category
        System.out.println("Shift 1: R50 per hour"); //First shift is at R50 an hour
        System.out.println("Shift 2: R70 per hour"); //Second shift is at R70 an hour
        System.out.println("Shift 3: R90 per hour"); //Third shift is at R90 an hour
        int shiftInt = sc.nextInt(); //Shift category collected from user input
        System.out.println("");
        
        
        //IN SHIFTS INPUT IS EQUAL TO 1
        if (shiftInt == 1) { //If 1st category
            shift = 50; //Shift rate is at R50 per hour
            
            System.out.println("Hours: " + hours); //Prints the hours
            System.out.println("Shift: 1st"); //Prints '1st' shift
            System.out.println("Rate: R50 per hour"); //Prints the rate
            System.out.println("");
            
            pay.dispCalc(); //Performs calculations applicable
            ret.regularNet(); //Prints the regular net pay
        
        //IF SHIFTS INPUT IS EQUAL TO 2
        } else if (shiftInt == 2) { //If 2nd category
            shift = 70; //Shift rate is at R70 an hour
            
            System.out.println("Would you like to apply for a retirement fund? (yes/no)"); //Prompt for retirement
            input = sc.next(); //Collects user input and stores it in variable 'input'
            
            System.out.println("");
            System.out.println("Hours: " + hours); //Prints the hours
            System.out.println("Shift: 2nd"); //Prints '2nd' shift
            System.out.println("Rate: R70 per hour"); //Prints the rate
            System.out.println("");
            
            pay.dispCalc(); //Performs calculations applicable
            ret.perfRetire(); //Performs retirement calculations
            
        //IF SHIFTS INPUT IS EQUAL TO 3
        } else if (shiftInt == 3) { //If 3rd category
            shift = 90;
            
            System.out.println("Would you like to apply for a retirement fund? (yes/no)"); //Prompt for retirement
            input = sc.next(); //Collects user input and store it in variable 'input'
            
            System.out.println("");
            System.out.println("Hours: " + hours); //Prints the hours
            System.out.println("Shift: 3rd"); //Prints '3rd' shift
            System.out.println("Rate: R90 per hour"); //Prints the rate
            System.out.println("");
            
            pay.dispCalc(); //Performs calculations applicable
            ret.perfRetire();  //Performs retirement calculations
        } else {
            System.out.println("Invalid input.");
        }
        
        try {
            RandomAccessFile file = new RandomAccessFile("Hours and Shifts.txt", "rw"); //Creates a text file called "Hours and Shifts.txt"
            file.seek(file.length());
            file.writeBytes("Hours: " + String.valueOf(hours) + "\n"); //Prints inputted hours
            file.writeBytes("Shift: R" + String.valueOf(shift) + " per hour" + "\n"); //Prints inputted shift
            file.writeBytes(" "); //Prints a space
            file.close();
        } catch (IOException exception) {
            exception.printStackTrace();
        }
        
    }
    
}
